package Modelos;

public class Compra {
    //Atributos de la Clase
    protected String tipoCompra;
    
    //Constructor Por Defecto
    public Compra(){
        
    }
    //Constructor Parametrizado
    public Compra(String tipoCompra){
        this.tipoCompra = tipoCompra;
    }
}
