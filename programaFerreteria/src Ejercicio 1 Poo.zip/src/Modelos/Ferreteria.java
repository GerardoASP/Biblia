
package Modelos;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Ferreteria {
    //Atributos de la Clase
    protected ArrayList<Sucursal> listaSucursales;
    protected ArrayList<Producto> listaProductos;
    //Constructor Por Defecto
    public Ferreteria(){
        this.listaSucursales = new ArrayList<>();
        this.listaProductos = new ArrayList<>();
    }
    
    //Metodos de la Clase
    protected void trasladarMercancia(){
        JOptionPane.showMessageDialog(null,"Trasladando mercancia a la Sucursal");
    }
    
    protected void surtirSucursales(ArrayList<Producto> listaProductos,ArrayList<Producto> listaProductosOp){
        for(int i=0;i<listaProductos.size();i++){
            listaProductosOp.add(listaProductos.get(i));
        }
    }
    
    protected void asesorarProyectos(){
        JOptionPane.showMessageDialog(null,"Para su proyecto le recomendamos...");
    }
    
    protected void atenderVentas(){
        JOptionPane.showMessageDialog(null,"Bienvenido señor/a usuario en que podemos colaborarle");
    }
    
    protected String alquilarHerramientas(String nombreCliente,long numDocumento,int dinero){
        String respuestaAlquiler;
        
        respuestaAlquiler = "La herramienta esta disponible para prestamo";
        
        return respuestaAlquiler;
    }
}
