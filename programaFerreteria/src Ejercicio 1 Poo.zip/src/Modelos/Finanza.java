
package Modelos;

import java.util.ArrayList;

public class Finanza {
    //Atributos de la clase
    protected ArrayList<Inventario> listaInventarios;
    
    //Constructor Por Defecto
    public Finanza(){
        this.listaInventarios = new ArrayList<>();
    }
}
