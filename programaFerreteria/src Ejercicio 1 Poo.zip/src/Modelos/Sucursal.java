
package Modelos;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Sucursal {
    //Atributos de la clase
    protected String localicacion;
    private String logistica;
    protected ArrayList<Cliente> listaClientes;
    protected ArrayList<Producto> listaProductosS;
    
    //Constructor Por Defecto
    public Sucursal(){
        this.listaClientes = new ArrayList<>();
        this.listaProductosS = new ArrayList<>();
    }
    //Constructor Parametrizado
    public Sucursal(String localicacion,String logistica){
        this.localicacion = localicacion;
        this.logistica = logistica;
    }
    //Serie de Getters And Setters
    public String getLogistica(){
        return this.logistica;
    }
    public void setLogistica(String logistica){
        this.logistica = logistica;
    }
    
    //Metodos de la Clase
    protected void controlarInventario(ArrayList<Producto> listaProductos){
        if(listaProductos.size() <= 0){
            JOptionPane.showMessageDialog(null,"Alerta");
        }else{
            JOptionPane.showMessageDialog(null,"Inventario Lleno");
        }
    }
    
    protected String generarInformePrincipal(Producto p,Cliente c,VendedorExterno ve){
        String retornoInforme;
        retornoInforme = "El producto " + p.nombre + "Ha sido Comprado por El Cliente con el nombre " + c.nombre + "y numero de documento" + c.numDocumento + "Con Ayuda del Vendedor Externo de nombre " + ve.nombre;
        return retornoInforme;
    }
    
    protected void atenderVentas(){
        JOptionPane.showMessageDialog(null,"Bienvenidos a la Ferreteria en que podemos servirle");
    }
}
